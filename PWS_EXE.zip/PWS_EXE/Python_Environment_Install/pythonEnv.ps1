﻿$url = "https://repo.continuum.io/miniconda/Miniconda3-latest-Windows-x86_64.exe"
$output = "C:\MinicondaInstaller.exe"

Write-Output "Getting Miniconda..."
Invoke-WebRequest -Uri $url -OutFile $output

Write-Output "Running Miniconda Installer..."
C:\MinicondaInstaller.exe /InstallationType=AllUsers /AddToPath=1 /RegisterPython=1 /S /D=C:\Anaconda

Write-Output "Installing python packages..."

del $output

setx /M path "C:\Anaconda\Scripts;C:\Anaconda;C:\windows\System32;%path%"
set path "C:\Anaconda\Scripts;C:\Anaconda;C:\windows\System32;%path%"

conda update -y -q conda
conda install -y -q python=3.6.7
conda install -y -q pip
conda install -y -q numpy pandas scipy
conda install -y -q matplotlib seaborn
conda install -y -q scikit-learn
conda install -y -q bokeh selenium phantomjs pillow
conda install -y -q tensorflow tensorflow-gpu
conda install -y -q pytorch -c pytorch 
conda install -y -q keras
conda install -y -q jupyter

$dummy = Read-Host 'Hit enter to exit'