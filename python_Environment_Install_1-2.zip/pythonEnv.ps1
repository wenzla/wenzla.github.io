﻿$url = "https://repo.continuum.io/miniconda/Miniconda3-latest-Windows-x86_64.exe"
$output = "C:\MinicondaInstaller.exe"

Write-Output "Getting Miniconda..."
Invoke-WebRequest -Uri $url -OutFile $output

Write-Output "Running Miniconda Installer..."
C:\MinicondaInstaller.exe /InstallationType=AllUsers /AddToPath=1 /RegisterPython=1 /S /D=C:\Anaconda

Write-Output "Installing python packages..."

del $output

setx /M path "C:\Anaconda\Scripts;C:\Anaconda;%path%"

conda update -y conda
conda install -y python=3.6.7
conda install -y pip
conda install -y numpy pandas scipy
conda install -y matplotlib seaborn
conda install -y scikit-learn
conda install -y bokeh selenium phantomjs pillow
conda install -y tensorflow tensorflow-gpu
conda install -y pytorch -c pytorch 
conda install -y keras
conda install -y jupyter

$dummy = Read-Host 'Type anything and hit enter to exit:'